using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using TMPro;

public class LeaderboardManager : MonoBehaviour
{
    public string url = "http://localhost:5149/leaderboard";
    public TMP_Text leaderboardText;

    void Start()
    {
        Debug.Log("URL: " + url);
        StartCoroutine(GetLeaderboardCoroutine());
    }

    public void GetLeaderboard()
    {
        StartCoroutine(GetLeaderboardCoroutine());
    }

    IEnumerator GetLeaderboardCoroutine()
    {
        Debug.Log("Yhdistet��n: " + url);

        using UnityWebRequest request = UnityWebRequest.Get(url);
        request.timeout = 5;
        yield return request.SendWebRequest();

        Debug.Log("Result: " + request.result);
        Debug.Log("ResponseCode: " + request.responseCode);
        Debug.Log("Error: " + request.error);
        Debug.Log("Text: " + request.downloadHandler.text);

        if (request.result == UnityWebRequest.Result.Success)
        {
            string json = "{\"scores\":" + request.downloadHandler.text + "}";
            ScoreList list = JsonUtility.FromJson<ScoreList>(json);
            ShowLeaderboard(list);
        }
        else
        {
            leaderboardText.text = "Virhe: " + request.error;
            Debug.LogError("Virhe: " + request.error);
        }
    }

    void ShowLeaderboard(ScoreList list)
    {
        leaderboardText.text = "TOP 5\n";
        for (int i = 0; i < list.scores.Length; i++)
        {
            var s = list.scores[i];
            leaderboardText.text += $"{i + 1}. {s.name} - {s.points}\n";
        }
    }
}