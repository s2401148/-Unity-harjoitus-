using UnityEngine;

public class AreaTrigger : MonoBehaviour
{
    [SerializeField] private string areaName;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.LogEvent($"Alueelle saavuttu: {areaName}");
            }
            else
            {
                Debug.LogWarning("LogManager ei l�ydy skenest�!");
            }
        }
    }
}