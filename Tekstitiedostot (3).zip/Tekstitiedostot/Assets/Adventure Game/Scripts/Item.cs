using UnityEngine;

public class Item : MonoBehaviour
{
    [SerializeField] private string itemName;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.LogEvent($"Esine ker�tty: {itemName}");
            }
            else
            {
                Debug.LogWarning("LogManager ei l�ydy skenest�!");
            }

            Destroy(gameObject);
        }
    }
}