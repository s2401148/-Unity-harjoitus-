using UnityEngine;

public class Npc : MonoBehaviour
{
    [SerializeField] private string npcName;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (LogManager.Instance != null)
            {
                LogManager.Instance.LogEvent($"Keskustelu aloitettu: {npcName}");
            }
            else
            {
                Debug.LogWarning("LogManager ei l�ydy!");
            }
           
        }
    }
}