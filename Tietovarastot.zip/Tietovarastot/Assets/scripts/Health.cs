﻿using UnityEngine;
using TMPro;

public class Health : MonoBehaviour
{
    [SerializeField] private int maxHealth = 100;
    [SerializeField] private TMP_Text hpText; 

    private int currentHealth;

    public int CurrentHealth
    {
        get => currentHealth;
        set
        {
            currentHealth = value;
            UpdateHPText(); 
        }
    }

    void Awake()
    {
        currentHealth = maxHealth;
    }

    public void Modify(int amount)
    {
        currentHealth += amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        Debug.Log("Health: " + currentHealth);
        UpdateHPText(); 
    }

    public void UpdateHPText()
    {
        if (hpText != null)
        {
            hpText.text = "HP=" + currentHealth;
        }
    }
}