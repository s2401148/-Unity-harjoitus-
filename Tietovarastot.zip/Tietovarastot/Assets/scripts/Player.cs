﻿using System.IO;
using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class Player : MonoBehaviour
{
    public Health health;
    public int score = 0; 

    [SerializeField] private TMP_Text scoreText; 

    void Awake()
    {
        health = GetComponent<Health>();
    }

    private void Start()
    {
        if (health == null)
        {
            Debug.LogError("Health-komponentti puuttuu");
        }

        string path = $"{Application.dataPath}/playerData.json";
        if (File.Exists(path))
        {
            Load();
        }

        UpdateScoreText();
    }

    private void Update()
    {
        if (Keyboard.current.tKey.wasPressedThisFrame) TakeDamage(1);
        if (Keyboard.current.hKey.wasPressedThisFrame) Heal(1);
        if (Keyboard.current.yKey.wasPressedThisFrame) Save();
    }

    public void TakeDamage(int amount)
    {
        health.Modify(-amount);
    }

    public void Heal(int amount)
    {
        health.Modify(amount);
    }

    public void AddScore(int amount)
    {
        score += amount;
        UpdateScoreText();
        Debug.Log("Score: " + score);
    }

    public void UpdateScoreText()
    {
        if (scoreText != null)
        {
            scoreText.text = "Score=" + score;
        }
    }

    public void Save()
    {
        Debug.Log("JSON-tallennus käynnissä");
        PlayerData playerData = new PlayerData(this);
        string json = JsonUtility.ToJson(playerData);
        File.WriteAllText($"{Application.dataPath}/playerData.json", json);
        Debug.Log("Tallennettu: " + json);
    }

    public void Load()
    {
        Debug.Log("JSON-lataus käynnissä");
        string json = File.ReadAllText($"{Application.dataPath}/playerData.json");
        PlayerData playerData = JsonUtility.FromJson<PlayerData>(json);
        health.CurrentHealth = playerData.health;
        score = playerData.score; 
        UpdateScoreText();
    }
}