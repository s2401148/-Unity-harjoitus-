using UnityEngine;

public class SavePoint : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        
        Player player = other.GetComponent<Player>();

        if (player != null)
        {
            Debug.Log("SavePoint: tallennetaan...");
            player.Save();
        }
    }
}