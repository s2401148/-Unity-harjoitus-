﻿using UnityEngine;

public class Collectible : MonoBehaviour
{
    [SerializeField] private int scoreValue = 10;

    private void OnTriggerEnter(Collider other)
    {
        Player player = other.GetComponent<Player>();

        if (player != null)
        {
            player.AddScore(scoreValue);
            Debug.Log("Pisteitä saatu: " + scoreValue);
            Destroy(gameObject); 
        }
    }
}