﻿var builder = WebApplication.CreateBuilder(args);


builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.PropertyNamingPolicy =
        System.Text.Json.JsonNamingPolicy.CamelCase;
});

var app = builder.Build();


app.UseCors();

List<Score> scores = new()
{
    new Score("Leyla", 50),
    new Score("Arto", 20),
    new Score("Sofia", 70),
    new Score("David", 90),
    new Score("Eeva", 40)
};

app.MapPost("/score", (Score score) =>
{
    scores.Add(score);
    return Results.Ok();
});

app.MapGet("/leaderboard", () =>
{
    return scores
        .OrderByDescending(s => s.Points)
        .Take(5);
});

app.Run();

record Score(string Name, int Points);